import cv2 as cv
import numpy as np

brow_R = cv.imread('dst_brow_R.jpg')

brow_R_height, brow_R_width = brow_R.shape[0:2] #해상도 확인

for i in range(0,brow_R_height):
    for j in range(0,brow_R_width):
        if brow_R[i,j][2] > 128 :
            print(" " , end="")
        else :
            print("." , end="")
    print()


brow_L = cv.imread('dst_brow_L.jpg')

brow_L_height, brow_L_width = brow_L.shape[0:2] #해상도 확인

for i in range(0,brow_L_height):
    for j in range(0,brow_L_width):
        if brow_L[i,j][2] > 128 :
            print(" " , end="")
        else :
            print("." , end="")
    print()

cv.waitKey(0)
