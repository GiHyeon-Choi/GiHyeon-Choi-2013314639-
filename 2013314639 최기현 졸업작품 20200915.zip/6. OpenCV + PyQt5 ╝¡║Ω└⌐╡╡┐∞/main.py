import sys
import time
from MainWindow import MainWindow
from PyQt5.QtWidgets import *
from capture_module import capture

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    capture() #capture은 얼굴이 검출되면 자동으로 찍고 얼굴을 DB에서 찾는다
    sys.exit(app.exec_())
