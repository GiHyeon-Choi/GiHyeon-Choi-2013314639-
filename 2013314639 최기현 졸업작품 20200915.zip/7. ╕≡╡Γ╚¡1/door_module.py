import cv2
import time
import sys

def door_start():
    num_of_img = 20
    img = []
    for i in range(0,num_of_img) :
        filename = "img/" + str(i+1) + ".jpg"
        tmp = cv2.imread(filename)
        img.append(tmp)
    
    img_no = 0
    
    door_status = 1 #0 closed, 1 opening, 2 opened , 3 closing
    
    while(True):
        time.sleep(0.01)

        #다음 이미지는?
        if door_status == 0 :
            img_no = 0
        elif door_status == 1 :
            if img_no == 19 :
                img_no = 0
            img_no = img_no + 1
            if img_no == num_of_img -1:
                door_status = 2
        elif door_status == 2 :
            img_no = num_of_img - 1
        else :
            if img_no == 0 :
                img_no = 19
            img_no = img_no - 1
            if img_no == 1:
                door_status = 0

        cv2.imshow('door', img[img_no])

                
        tmp_kb = cv2.waitKey(1)
    
