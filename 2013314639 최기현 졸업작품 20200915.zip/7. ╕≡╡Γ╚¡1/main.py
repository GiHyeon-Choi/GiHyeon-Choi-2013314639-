import sys
import time
import threading
from WindowMain import WindowMain
from PyQt5.QtWidgets import *
from capture_module import capture_start
from door_module import door_start

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = WindowMain()
    win.show()
    th1 = threading.Thread(target=door_start)
    th1.start()
    th2 = threading.Thread(target=capture_start)
    th2.start()
    sys.exit(app.exec_())
 
