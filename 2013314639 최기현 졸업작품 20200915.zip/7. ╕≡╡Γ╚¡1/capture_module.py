import cv2
import pymysql
import time
import sys
from PIL import Image
from PIL import ImageEnhance
from time import sleep

global cnt
global msg
global msg_time

def capture_start():
    
    filename_jpg = ""

    cap1 = cv2.VideoCapture(0)
    cap2 = cv2.VideoCapture(1)

    #print('width :%d, height : %d' % (cap.get(3), cap.get(4)))
    cnt = 0
    msg = ""
    msg_time = 0
    
    while(True):

        ret1, frame1 = cap1.read()    # Read 결과와 frame
        ret2, frame2 = cap2.read()    # Read 결과와 frame
            
        if ret1 :
            frame1_e = cv2.flip(frame1, 1)
            frame1_e = cv2.rectangle(frame1_e, (260, 230), (270, 240), (255, 255, 0), 2)
            frame1_e = cv2.rectangle(frame1_e, (380, 230), (370, 240), (255, 255, 0), 2)
            frame1_e = cv2.rectangle(frame1_e, (300, 360), (340, 370), (255, 255, 0), 2)

            frame2_e = cv2.flip(frame2, 1)
            frame2_e = cv2.rectangle(frame2_e, (300, 230), (310, 240), (255, 255, 0), 2)
            frame2_e = cv2.rectangle(frame2_e, (300, 350), (310, 360), (255, 255, 0), 2)
            
            if msg_time != 0 :
                frame1_e = cv2.putText(frame1_e, msg, (0, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0))
                msg_time = msg_time -1
                
            merged = cv2.vconcat([frame1_e,frame2_e])

            cv2.imshow('camera', merged)    # 컬러 화면 출력

            tmp_kb = cv2.waitKey(1) #키보드 입력을 임시로 저장

            #눈동자 판별
            l_eye = [0,0,0]
            l_eye_w = [0,0,0]
            
            r_eye = [0,0,0]
            r_eye_w = [0,0,0]
            
            for i in range(230,240) :
                for j in range(260,270) : #왼쪽 눈동자
                    l_eye = l_eye + frame1[i,j]
                for j in range(370,380) : #오른쪽 눈동자
                    r_eye = r_eye + frame1[i,j]

            #왼쪽 흰자
            for i in range(233,247) : 
                for j in range(250,255) :
                    l_eye_w = l_eye_w + frame1[i,j]
                for j in range(275,280) :
                    l_eye_w = l_eye_w + frame1[i,j]

            #오른쪽 흰자
            for i in range(233,247) : 
                for j in range(360,365) :
                    r_eye_w = r_eye_w + frame1[i,j]
                for j in range(385,390) :
                    r_eye_w = r_eye_w + frame1[i,j]


            if (l_eye[1]<8000) and (l_eye[2]<8000) and (r_eye[1]<8000) and (r_eye[2]<8000) :
                if (l_eye_w[0]>2000) and (r_eye_w[0]>2000) :
                    cnt = cnt +1

            #눈이 포착되었다 생각되는 사진을 80장 마다 저장
            if cnt != 0 :
                if cnt % 100 == 50 :
                    cv2.imwrite("front_o.png", frame1)
                    cv2.imwrite("side_o.png", frame2)

                    sleep(0.5)
                    
                    tmp1 = Image.open("front_o.png")
                    enhancer1 = ImageEnhance.Color(tmp1)
                    gray1 = enhancer1.enhance(0)
                    enhancer1 = ImageEnhance.Contrast(gray1)
                    cont1 = enhancer1.enhance(2)
                    front1 = cont1.resize((320, 240))
                    front1.save("front.jpg")

                    tmp2 = Image.open("side_o.png")
                    enhancer2 = ImageEnhance.Color(tmp2)
                    gray2 = enhancer2.enhance(0)
                    enhancer2 = ImageEnhance.Contrast(gray2)
                    cont2 = enhancer2.enhance(2)
                    front2 = cont2.resize((320, 240))
                    front2.save("side.jpg")

                    msg = "Face has been captured..."
                    msg_time = 10
                if cnt % 25 == 0 :
                    print("eye")
                if cnt % 100 == 0 :
                    cnt = 0

        sleep(0.1) #프레임 조절용
        
    cap1.release()
    cap2.release()
    cv2.destroyAllWindows()

    sleep(1)

    im = Image.open(filename_jpg)
     
    # 이미지 크기 출력
    print(im.size)

    enhancer = ImageEnhance.Contrast(im)
    new_img = enhancer.enhance(5)
    new_img = new_img.resize((320, 240))
     
    # 이미지 JPG로 저장
    filename2 = time.strftime('%Y-%m-%d %H%M%S converted', time.localtime(time.time())) + ".bmp"
    new_img.save(filename2)


    #목표 : 전면 이미지에서 눈썹 눈 콧구멍 입술의 위치를 찾기
