CREATE DATABASE IF NOT EXISTS facedb;
USE facedb;

CREATE TABLE `accounts` (
  `itemid` int(11) NOT NULL,
  `name` VARCHAR(50) NOT NULL DEFAULT '',
  `front` BLOB ,
  `side` BLOB ,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=euckr ROW_FORMAT=DYNAMIC;