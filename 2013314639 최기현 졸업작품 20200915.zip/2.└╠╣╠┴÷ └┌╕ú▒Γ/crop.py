import cv2

src = cv2.imread("test.jpg", cv2.IMREAD_COLOR)

dst_brow_L = src.copy() 
dst_brow_L = src[80:110, 90:160] #상:하 , 좌:우

dst_brow_R = src.copy() 
dst_brow_R = src[80:110, 160:230] #상:하 , 좌:우

cv2.imshow("src", src)
cv2.imshow("dst_brow_L", dst_brow_L)
cv2.imwrite("dst_brow_L.jpg",dst_brow_L) #save
cv2.imshow("dst_brow_R", dst_brow_R)
cv2.imwrite("dst_brow_R.jpg",dst_brow_R) #save
cv2.waitKey(0)
cv2.destroyAllWindows()
