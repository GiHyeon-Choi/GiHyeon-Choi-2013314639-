import cv2
import time
import sys
from PIL import Image
from PIL import ImageEnhance
from time import sleep


filename_jpg = ""

cap = cv2.VideoCapture(0)

print('width :%d, height : %d' % (cap.get(3), cap.get(4)))

while(True):
    
    ret, frame = cap.read()    # Read 결과와 frame    

    if(ret) :
        gray = cv2.cvtColor(frame,  cv2.COLOR_BGR2GRAY)    # 입력 받은 화면 Gray로 변환
        frame = cv2.flip(frame, 1)
        frame = cv2.rectangle(frame, (260, 230), (270, 240), (255, 0, 0), 2)
        frame = cv2.rectangle(frame, (380, 230), (370, 240), (255, 0, 0), 2)

        cv2.imshow('frame_color', frame)    # 컬러 화면 출력

        tmp_kb = cv2.waitKey(1) #키보드 입력을 임시로 저장

        #키보드입력 판별
        if tmp_kb == ord('s') :
            filename_jpg = time.strftime('%Y-%m-%d %H%M%S', time.localtime(time.time())) + ".png"
            cv2.imwrite(filename_jpg, gray) #캡쳐
            break
        if tmp_kb == ord('q') :
            exit()
        
            
cap.release()
cv2.destroyAllWindows()

sleep(1)

im = Image.open(filename_jpg)
 
# 이미지 크기 출력
print(im.size)

enhancer = ImageEnhance.Contrast(im)
new_img = enhancer.enhance(5)
new_img = new_img.resize((320, 240))
 
# 이미지 JPG로 저장
filename2 = time.strftime('%Y-%m-%d %H%M%S converted', time.localtime(time.time())) + ".bmp"
new_img.save(filename2)


#목표 : 전면 이미지에서 눈썹 눈 콧구멍 입술의 위치를 찾기
