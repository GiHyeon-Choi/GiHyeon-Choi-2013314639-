CREATE TABLE `accounts` (
  `itemid` int(11) NOT NULL,
  `name` VARCHAR(50) NOT NULL DEFAULT '',
  `img` BLOB ,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=euckr ROW_FORMAT=DYNAMIC;