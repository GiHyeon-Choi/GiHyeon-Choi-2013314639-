import cv2
import time
import threading
import sys
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from SubWindow import SubWindow

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        
        self.setWindowTitle('Main Window') #창제목 설정
        self.setGeometry(100, 100, 300, 200) #창 범위 설정

    
        #레이아웃 설정
        layout = QVBoxLayout()
        layout.addStretch(1)
        label_msg = QLabel("캡쳐중")
        
        label_msg.setAlignment(Qt.AlignCenter)
        font = label_msg.font()
        font.setPointSize(30)
        label_msg.setFont(font)
        self.label_msg = label_msg

        #실험구간
        img = cv2.imread('tmp.jpg')
        height, width = img.shape[:2]
        label_face = QLabel()
        label_face.resize(width, height)
        h,w,c = img.shape
        qImg = QImage(img.data, w, h, w*c, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qImg)
        label_face.setPixmap(pixmap)
        #실험구간 끝

        #버튼설정
        btn_optional_window = QPushButton("얼굴등록")
        btn_optional_window.clicked.connect(self.onButtonClicked)
        btn_password = QPushButton("비밀번호")
        btn_password.clicked.connect(self.onButtonClicked)
        layout.addWidget(label_face)
        layout.addWidget(label_msg)
        layout.addWidget(btn_optional_window)
        layout.addWidget(btn_password)
        layout.addStretch(1)
        centralWidget = QWidget()
        centralWidget.setLayout(layout)
        self.setCentralWidget(centralWidget)

        
    def onButtonClicked(self): #얼굴 캡쳐와 함께
        win = SubWindow()
        r = win.showModal()
        if r:
            text = win.edit.text()
            self.label_msg.setText(text)
    def show(self):
        super().show()

