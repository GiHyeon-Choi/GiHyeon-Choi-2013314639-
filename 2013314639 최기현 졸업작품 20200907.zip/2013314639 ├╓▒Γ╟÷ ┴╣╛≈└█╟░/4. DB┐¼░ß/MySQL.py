import pymysql
 
# MySQL Connection 연결
conn = pymysql.connect(host='localhost', user='root', password='root',
                       db='1', charset='utf8')
 
# Connection 으로부터 Cursor 생성
curs = conn.cursor()
 
# SQL문 실행
sql = "select * from accounts"
curs.execute(sql)
 
# 데이타 Fetch
rows = curs.fetchall()

itemid_next = str(rows[-1][0] + 1)

face = open('face.jpg', 'rb').read()


sql_insert = "INSERT INTO accounts VALUES ( " + itemid_next + " , '최기현' , (%s));"

curs.execute(sql_insert, (face,))

# Connection 닫기
conn.close()
