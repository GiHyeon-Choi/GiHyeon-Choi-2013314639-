import cv2
import time
import threading
import sys
from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore


running = False

mode_reg = 0
mode_cap = 0
notification_cnt = 0
notification_msg = ""

def run(): #화면 두개가 나오고 눈&입 가이드라인이 나오도록(모듈로 불러오기)
    
    global running
    
    global mode_reg
    global mode_cap
    global notification_cnt
    global notification_msg
    
    cap = cv2.VideoCapture(0)
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    label.resize(width, height)
    
    while running:
        
        ret, img = cap.read()
        
        if ret:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.flip(img, 1)
            img = cv2.rectangle(img, (260, 230), (270, 240), (255, 0, 0), 2)
            img = cv2.rectangle(img, (380, 230), (370, 240), (255, 0, 0), 2)
            img = cv2.hconcat([img,img]) #이미지 합치기

            if mode_cap is 1 :
                gray = cv2.cvtColor(img,  cv2.COLOR_BGR2GRAY) # 흑백
                filename_jpg = time.strftime('%Y-%m-%d %H%M%S', time.localtime(time.time())) + ".png"
                cv2.imwrite(filename_jpg, gray) #캡쳐
                mode_cap = 0 # 한번만 찍도록
                notification_cnt = 1
                notification_msg = "captured"

            if mode_reg is 1 :
                app = QApplication(sys.argv)
                capture_process = QLabel("Hello PyQt")
                label.show()
                app.exec_()

            #알림 메세지
            if notification_cnt is 50 : 
                notification_cnt = 0
                notification_msg = ""
            elif notification_cnt is not 0 :
                img = cv2.putText(img, notification_msg, (0, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0))
                notification_cnt = notification_cnt + 1
                
            h,w,c = img.shape
            qImg = QtGui.QImage(img.data, w, h, w*c, QtGui.QImage.Format_RGB888)
            pixmap = QtGui.QPixmap.fromImage(qImg)
            label.setPixmap(pixmap)
            
            
        else:
            QtWidgets.QMessageBox.about(win, "Error", "Cannot read frame.")
            print("cannot read frame.")
            break
    cap.release()
    print("Thread end.")

def stop():
    global running
    running = False
    print("stoped..")

def start():
    global running
    running = True
    th = threading.Thread(target=run)
    th.start()
    print("started..")

def onExit():
    print("exit")
    stop()

def reg():
    print("register mode")
    global mode_reg #def 안에서 전역변수 이용시 global을 써줘야 함
    mode_reg = 1

def cap(): #캡쳐한 이후로는 DB에 등록하는 창이 뜨도록
    print("capture")
    global mode_cap
    mode_cap = 1

def reset():
    print("reset")
    global mode_reg
    mode_reg = 0

def password():
    print("exit")
    stop()



app = QtWidgets.QApplication([])
win = QtWidgets.QWidget()
vbox = QtWidgets.QVBoxLayout()
label = QtWidgets.QLabel()

start()


btn_reg = QtWidgets.QPushButton("얼굴 등록") #새 카메라 창이 뜨고 촬영시작
btn_cap = QtWidgets.QPushButton("얼굴 캡쳐") 
btn_password = QtWidgets.QPushButton("비밀번호 입력") #카메라가 꺼지고 비밀번호 입력모드로 전환
btn_reset = QtWidgets.QPushButton("첫 화면으로") #하던 작업을 모두 날리고 초기화

vbox.addWidget(label)
vbox.addWidget(btn_reg)
vbox.addWidget(btn_cap)
vbox.addWidget(btn_password)
vbox.addWidget(btn_reset)

win.setLayout(vbox)
win.show()

btn_reg.clicked.connect(reg)
btn_cap.clicked.connect(cap)
btn_password.clicked.connect(password)
btn_reset.clicked.connect(reset)
app.aboutToQuit.connect(onExit)

sys.exit(app.exec_())
