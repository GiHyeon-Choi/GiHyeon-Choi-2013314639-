import pymysql
import cv2

def download_faces() :
    conn = pymysql.connect(host='localhost', user='root', password='root', db='facedb', charset='utf8')
    curs = conn.cursor()

    sql = "select * from accounts"
    curs.execute(sql)

    rows = curs.fetchall()
    
    f3_str = ''
    
    for i in range(1,len(rows)) :
        f1 = open('faces/'+str(rows[i][0])+'_front.jpg','wb')
        f1.write(rows[i][3])
        f1.close()
        f2 = open('faces/'+str(rows[i][0])+'_side.jpg','wb')
        f2.write(rows[i][4])
        f2.close()
        f3_str = f3_str + str(rows[i][0]) + ',' + rows[i][1] + ',' + str(rows[i][2]) + '\n'
 
    
    
    f3 = open("faces/list.txt", 'w')
    f3.write(f3_str)
    f3.close()

    #f1_img = cv2.imread('front_dl.jpg')
    #cv2.imshow('image', f1_img )

    conn.close()

download_faces()
