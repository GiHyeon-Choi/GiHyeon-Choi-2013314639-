#각좌표계 점찍기 테스트

import cv2
import time
import math

def comparison_each(filename1 , filename2 ): 

    similarity = 0
    
    radius = 50
    division = 90
    interval = (2*math.pi)/division

    empty_img = cv2.imread('empty.jpg') #도화지

    face_img = cv2.imread(filename1) #방금찍은 사진

    target_img = cv2.imread(filename2) #db의 사진

    height, width , channel = empty_img.shape

    h_center = int(height/2)
    w_center = int(width/2)


    face_circle = []

    for i in range(0,radius) :
        face_circle.append([])
        for j in range(0,division) :
            y = int(i*math.sin(j*interval) +h_center)
            x = int(i*math.cos(j*interval) +w_center)
            face_circle[i].append(face_img[y][x])

    rotation = 2
    verti_move = 1
    hori_move = 1

    #cnt = 0
    for r in range(-rotation,rotation) :
        for v in range(-verti_move,verti_move) :
            for h in range(-hori_move,hori_move) :
                for i in range(0,radius) :
                    for j in range(0,division) :
                        y = int(i*math.sin(j*interval+r/100) +h_center +v)
                        x = int(i*math.cos(j*interval+r/100) +w_center +h)
                        empty_img[y][x] = face_circle[i][j]
                #cv2.imshow('circle', empty_img)

                tmp_sim = 0
                for v_t in range(70,height-20) :
                    for h_t in range(40,width-40) :
                        diff = abs(int(empty_img[v_t][h_t][0]) - int(target_img[v_t][h_t][0]))
                        c_origin = int(empty_img[v_t][h_t][0])
                        c_target = int(target_img[v_t][h_t][0])

                        if diff > 90 : #색차이가 심하게 나면 감점을 많이
                            tmp_sim = tmp_sim -5
                        elif diff < 10 : #색차이가 거의 똑같을땐 가점을 약간
                            tmp_sim = tmp_sim +1
                            
                            
                if tmp_sim > similarity :
                    similarity = tmp_sim


                #if cnt % 2 == 0:
                #    cv2.imshow("show",empty_img)
                #else :
                #    cv2.imshow("show",target_img)
                #tmp_kb = cv2.waitKey(1)
                
                #cnt = cnt+1

                    
                empty_img = cv2.imread('empty.jpg') #이미지 초기화

                
    return similarity

def comparison():

    max_sim = 0
    max_sim_no = '0'    
    
    filename_f = 'front_border.jpg' #방금 찍은거
    filename_s = 'side_border.jpg' #방금 찍은거

    try :
        f = open("faces/list.txt", 'r')
    except :
        return 0
    
    img_no_list = []

    while True:
        line = f.readline()
        if not line:
            break

        img_no_list.append(line[0])
    f.close()
    
    for i in range(0,len(img_no_list)) :

        filename_f_dl = 'faces/' + img_no_list[i] + '_front.jpg' #비교대상들
        filename_s_dl = 'faces/' + img_no_list[i] + '_side.jpg' #비교대상들
        tmp = comparison_each(filename_f , filename_f_dl) + comparison_each(filename_s , filename_s_dl)
        if tmp > max_sim :
            max_sim = tmp
            max_sim_no = img_no_list[i]

    #print(max_sim , max_sim_no)

    if max_sim > 500 :
        return int(max_sim_no)
    else :
        return 0
            
