# 2013314639 Choi Gi Hyeon 최기현

import cv2
import time
import math

def comparison_each(filename1 , filename2 ): 

    similarity = 0
    
    radius = 50 # face radius
    division = 90 # face density
    
    interval = (2*math.pi)/division

    empty_img = cv2.imread('empty.jpg') 

    face_img = cv2.imread(filename1) # captured right before

    target_img = cv2.imread(filename2) #DB's face image

    height, width , channel = empty_img.shape

    h_center = int(height/2)
    w_center = int(width/2)


    face_circle = [] # Polar Coordinate face data

    # make the face into polar coordinate
    for i in range(0,radius) :
        face_circle.append([])
        for j in range(0,division) :
            y = int(i*math.sin(j*interval) +h_center)
            x = int(i*math.cos(j*interval) +w_center)
            face_circle[i].append(face_img[y][x])

    # error range value
    rotation = 2
    verti_move = 1
    hori_move = 1

    
    for r in range(-rotation,rotation) :
        for v in range(-verti_move,verti_move) :
            for h in range(-hori_move,hori_move) :
                for i in range(0,radius) :
                    for j in range(0,division) :
                        # error range values varies the cases and gets more accuracy
                        y = int(i*math.sin(j*interval+r/100) +h_center +v)
                        x = int(i*math.cos(j*interval+r/100) +w_center +h)
                        empty_img[y][x] = face_circle[i][j] # reconstruct polar coordinate image to rectangular 
                #cv2.imshow('circle', empty_img)

                tmp_sim = 0
                for v_t in range(70,height-20) :
                    for h_t in range(40,width-40) :
                        # get the diffence of the current one's face and the residents' faces
                        diff = abs(int(empty_img[v_t][h_t][0]) - int(target_img[v_t][h_t][0]))
                        c_origin = int(empty_img[v_t][h_t][0])
                        c_target = int(target_img[v_t][h_t][0])

                        if diff > 90 : # when the pixel's brightness is no same
                            tmp_sim = tmp_sim -5
                        elif diff < 10 : # when the pixel's brightness is almost same
                            tmp_sim = tmp_sim +1
                            
                # update this case's similarity
                if tmp_sim > similarity :
                    similarity = tmp_sim

                empty_img = cv2.imread('empty.jpg') # reset image
                
    return similarity

def comparison():
    
    # a candidate who has the best similarity with the current one.
    max_sim = 0
    max_sim_no = '0'    

    # current one's face images
    filename_f = 'front_border.jpg'
    filename_s = 'side_border.jpg'


    try :
        f = open("faces/list.txt", 'r')
    except :
        return 0

    # get DB's images list
    img_no_list = []
    while True:
        line = f.readline()
        if not line:
            break
        img_no_list.append(line[0])
    f.close()

    # compare each residents' faces
    for i in range(0,len(img_no_list)) :
        filename_f_dl = 'faces/' + img_no_list[i] + '_front.jpg' # residents' front faces
        filename_s_dl = 'faces/' + img_no_list[i] + '_side.jpg' # residents' side faces
        tmp = comparison_each(filename_f , filename_f_dl) + comparison_each(filename_s , filename_s_dl) # get face similarity of each residents 
        if tmp > max_sim : # update the candidate whenever the algorithm found the new candidate
            max_sim = tmp
            max_sim_no = img_no_list[i]

    #print(max_sim , max_sim_no)

    if max_sim > 700 : # if the maximum similarity is under this value, current one is not the member of residents.
        return int(max_sim_no)
    else :
        return 0
            
