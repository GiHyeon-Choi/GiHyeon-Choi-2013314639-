# 2013314639 Choi Gi Hyeon 최기현

import cv2
import time
import sys
import os

# Delete all files used for face recognition
def delete_files() :
    file = ['op.txt','front.jpg','side.jpg','front_o.png','side_o.png']
    for i in range(0,len(file)):
        os.remove(file[i])

# Visuialization of automatic door and elevator
def apt_start():
    door_img = []
    for i in range(0,20) :
        filename = "door_img/" + str(i+1) + ".jpg"
        tmp = cv2.imread(filename)
        door_img.append(tmp)
    
    door_img_no = 0
    door_status = 0 #0 closed, 1 opening, 2 opened , 3 closing
    door_open_time = 0

    floor_img = []
    for i in range(0,29) :
        filename = "floor_img/" + str(i) + ".jpg"
        tmp = cv2.imread(filename)
        floor_img.append(tmp)

    # 0 ~ 28
    current_loc = 14 #current position of elevator
    target_loc = [] #posion where the elevator will go
    resident_loc = -7 #posion where the resident lives

    tick = 0
    
    while(True):
        if os.path.isfile('op.txt'):
            
            # when a face recognition is finished 
            if door_open_time == 0 :
                
                f = open("op.txt", 'r')
                resident_loc = (int(f.readline()) *7) -7
                if resident_loc  >= 0 : # when the resident lives in ground level
                    #open the automatic door
                    door_open_time = 70
                    door_status = 1
                if resident_loc >= 7 :#when the resident lives in 2~5 floor
                    #move the elevator to the ground level then the resident's floor
                    target_loc.append(0)
                    target_loc.append(resident_loc)
                f.close()
                delete_files()
                
            elif door_open_time == 1 :
                door_open_time = 0
                door_status = 3
                delete_files()
            else :
                door_open_time = door_open_time -1

        # when automatic door has been opened with a password
        if os.path.isfile('open.txt'):
            if door_open_time == 0 : 
                door_open_time = 70
                door_status = 1
            elif door_open_time == 1 :
                door_open_time = 0
                door_status = 3
                os.remove('open.txt')
            else :
                door_open_time = door_open_time -1
                
        time.sleep(0.05)

        # automatic door animation
        if door_status == 0 :
            door_img_no = 0
        elif door_status == 1 :
            if door_img_no == 19 :
                door_img_no = 0
            door_img_no = door_img_no + 1
            if door_img_no == 19:
                door_status = 2
        elif door_status == 2 :
            door_img_no = 19
        else :
            if door_img_no == 0 :
                door_img_no = 19
            door_img_no = door_img_no - 1
            if door_img_no == 1:
                door_status = 0

        # elevator animation
        if tick % 4 == 0 :
            if len(target_loc) > 0 :
                if target_loc[0] > current_loc :
                    current_loc = current_loc +1
                elif target_loc[0] < current_loc :
                    current_loc = current_loc -1
                else :
                    del target_loc[0]
            tick = 4

        # show the visualization of automatic door and elevator with cv2
        merged = cv2.vconcat([door_img[door_img_no],floor_img[current_loc]])
        cv2.imshow('APT', merged)

                
        tmp_kb = cv2.waitKey(1)

        tick = tick +1

