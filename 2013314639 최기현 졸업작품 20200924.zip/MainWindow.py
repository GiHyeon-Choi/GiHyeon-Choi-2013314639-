# 2013314639 Choi Gi Hyeon 최기현

import sys
import pymysql
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PwWindow import PwWindow
from RegWindow import RegWindow

pw = "1234"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setWindowTitle('Main Window')
        self.setGeometry(100, 100, 600, 600)
        layout = QVBoxLayout()

        # message label
        label = QLabel("") 
        label.setAlignment(Qt.AlignCenter)
        font = label.font()
        font.setPointSize(30)
        label.setFont(font)
        self.label = label

        # enter with password option
        btn1 = QPushButton("Enter with Password ")
        btn1.clicked.connect(self.onButtonClicked1)

        # face register 
        btn2 = QPushButton("Register Face")
        btn2.clicked.connect(self.onButtonClicked2)
        layout.addWidget(label)
        layout.addWidget(btn1)
        layout.addWidget(btn2)
        #layout.addStretch(1)
        centralWidget = QWidget()
        centralWidget.setLayout(layout)
        self.setCentralWidget(centralWidget)

                
    def onButtonClicked1(self):
        global pw
        win = PwWindow()
        r = win.showModal()
        if r:
            text_pw = win.edit.text() # get updated text from win(subwindow)
            if text_pw != pw :
                text = "Wrong Password!"
            else :
                text = "Welcome!"
                f = open("open.txt", 'w')
                f.close()                
            self.label.setText(text)
            
    def onButtonClicked2(self):
        global pw
        win = RegWindow()
        r = win.showModal()
        if r:
            text_floor = win.lb1.text() # floor current one selected
            text_name = win.edit1.text() # name current one entered
            text_pw = win.edit2.text() # password current one entered
            if text_floor == 'Your floor :' :
                text = "Register Fail!\nYou did not select the floor."
            elif text_pw != pw :
                text = "Register Fail!\nWrong Password!"
            else :
                # registering the face as a new resident
                # connect
                conn = pymysql.connect(host='localhost', user='root', password='root', db='facedb', charset='utf8')
                curs = conn.cursor()
                # SQL excute
                sql = "select * from accounts"
                curs.execute(sql)
                # data fetch
                rows = curs.fetchall()

                # make the new face's id
                max_itemid = 0
                for idx in range(0,len(rows)) :
                    if rows[idx][0] > max_itemid :
                        max_itemid = rows[idx][0]

                itemid_next = str(max_itemid+1)

                img1 = open('front_border.jpg', 'rb').read()
                img2 = open('side_border.jpg', 'rb').read()

                # insert the current faces into DB as blob
                sql_insert = "INSERT INTO accounts VALUES ( " + itemid_next + " , '"+text_name+"' , "+text_floor[:-1]+" , (%s) , (%s));"
                curs.execute(sql_insert, (img1 , img2))
                conn.close()

                # register completed
                text = text_name + " Welcome!\n" + text_floor + "st floor has been registered."
            self.label.setText(text)
    
    def show(self):
        super().show()
