# 2013314639 Choi Gi Hyeon 최기현

import sys
import time
import threading
from MainWindow import MainWindow
from PyQt5.QtWidgets import *
from capture_module import capture_start
from apt_module import apt_start

if __name__ == '__main__':
    app = QApplication(sys.argv)
    # GUI part\
    win = MainWindow()
    win.show()
    # APT animation part
    th1 = threading.Thread(target=apt_start)
    th1.start()
    # image capture part
    th2 = threading.Thread(target=capture_start)
    th2.start()
    sys.exit(app.exec_())
