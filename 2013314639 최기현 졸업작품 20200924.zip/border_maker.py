# 2013314639 Choi Gi Hyeon 최기현

import cv2
import time
        

def border_finder(a,b,img) : #find the border of difference of brightness
    result = 0
    h , w , c = img.shape
    # get the difference of the current pixel and the pixel's up,down,left and right pixels
    if a != 0 :
        result = result + abs(int(img[a][b][0])-int(img[a-1][b][0]))
    if a != h-1 :
        result = result + abs(int(img[a][b][0])-int(img[a+1][b][0]))
    if b != 0 :
        result = result + abs(int(img[a][b][0])-int(img[a][b-1][0]))
    if b != w-1 :
        result = result + abs(int(img[a][b][0])-int(img[a][b+1][0]))
    if 255-result < 0:
        total = 0
    else :
        total = 255-result
    return total


def border_maker() :
    img1 = cv2.imread('front.jpg')
    img2 = cv2.imread('side.jpg')

    img1_border = cv2.imread('empty.jpg')
    img2_border = cv2.imread('empty.jpg')
    img3_border = cv2.imread('empty.jpg')

    height, width , channel = img1.shape

    # get more darker whenever the brightness changes faster
    for i in range(0,height) :
        for j in range(0,width) :
            tmp1 = border_finder(i,j,img1)
            tmp2 = border_finder(i,j,img2)
            for k in range(0,3) :
                img1_border[i][j][k] = tmp1
                img2_border[i][j][k] = tmp2


    #adjust the horizontal level of the side face image
    adjust = 0
    black_no = 1
    for i in range(0,height) :
        for j in range(width-1,-1,-1) :
            if img2_border[i][j][0] == 10 :
                print(i,j)
                adjust = adjust + j - (width/2)
                black_no = black_no +1
                break
    adjust = int(adjust/black_no)

    # reconstruct the adjusted side face image
    for i in range(0,height) :
        for j in range(0,width) :
            if j-adjust < width :
                img3_border[i][j-adjust] = img2_border[i][j]
                
    
    cv2.imwrite("front_border.jpg", img1_border)
    cv2.imwrite("side_border.jpg", img3_border)


