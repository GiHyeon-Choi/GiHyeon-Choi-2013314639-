# 2013314639 Choi Gi Hyeon 최기현

import sys
from PyQt5.QtWidgets import *
class PwWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        
        self.setWindowTitle('Pw Window')
        self.setGeometry(100, 100, 200, 100)
        layout = QVBoxLayout()
        layout.addStretch(1)

        # password box
        label = QLabel("Enter APT Password")
        edit = QLineEdit()
        font = edit.font()
        font.setPointSize(20)
        edit.setFont(font)
        self.edit = edit
        subLayout = QHBoxLayout()
        
        btnOK = QPushButton("OK")
        btnOK.clicked.connect(self.onOKButtonClicked)
        btnCancel = QPushButton("Cancel")
        btnCancel.clicked.connect(self.onCancelButtonClicked)

        layout.addWidget(label)
        layout.addWidget(edit)
        
        subLayout.addWidget(btnOK)
        subLayout.addWidget(btnCancel)
        layout.addLayout(subLayout)
        layout.addStretch(1)
        self.setLayout(layout)
        
    def onOKButtonClicked(self):
        self.accept()
    def onCancelButtonClicked(self):
        self.reject()
    def showModal(self):
        return super().exec_()
