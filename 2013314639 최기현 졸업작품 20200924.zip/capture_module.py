# 2013314639 Choi Gi Hyeon 최기현

import cv2
import pymysql
import time
import sys
import os
from PIL import Image
from PIL import ImageEnhance
from time import sleep
from border_maker import border_maker
from download_faces import download_faces
from comparison import comparison

global cnt
global msg
global msg_time
global wait_time


cap_cnt = 100

def capture_start():

    cap1 = cv2.VideoCapture(0) # front camera
    cap2 = cv2.VideoCapture(1) # side camera

    cnt = 0
    msg = "" # on screen message
    msg_time = 0 # on screen message time
    wait_time = 0 # deley when a face has been captured

    cnt_p = 0
    
    while(True):

        ret1, frame1 = cap1.read()
        ret2, frame2 = cap2.read()
            
        if ret1 :
            frame1_e = cv2.flip(frame1, 1) # flip the front image to show like a mirror
            frame1_e = cv2.rectangle(frame1_e, (260, 230), (270, 240), (255, 255, 0), 2) # eye guide line
            frame1_e = cv2.rectangle(frame1_e, (380, 230), (370, 240), (255, 255, 0), 2) # eye guide line 
            frame1_e = cv2.rectangle(frame1_e, (300, 360), (340, 370), (255, 255, 0), 2) # moth guide line

            frame2_e = cv2.flip(frame2, 1)
            frame2_e = cv2.rectangle(frame2_e, (300, 230), (310, 240), (255, 255, 0), 2) # eye guide line
            frame2_e = cv2.rectangle(frame2_e, (300, 350), (310, 360), (255, 255, 0), 2) # mouth guide line
            
            if msg_time != 0 : # on screen message feature 
                frame1_e = cv2.putText(frame1_e, msg, (0, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0))
                msg_time = msg_time -1
                
            merged = cv2.vconcat([frame1_e,frame2_e]) # merge the front camera image and the side camera image

            cv2.imshow('camera', merged)    # show the two camera images

            tmp_kb = cv2.waitKey(1)

            # eye recognition part
            l_eye = [0,0,0]
            l_eye_w = [0,0,0]
            
            r_eye = [0,0,0]
            r_eye_w = [0,0,0]
            
            for i in range(230,240) :
                for j in range(260,270) : #left eye pupil
                    l_eye = l_eye + frame1[i,j]
                for j in range(370,380) : #right eye pupil
                    r_eye = r_eye + frame1[i,j]

            #left eye pupil(white)
            for i in range(233,247) : 
                for j in range(250,255) :
                    l_eye_w = l_eye_w + frame1[i,j]
                for j in range(275,280) :
                    l_eye_w = l_eye_w + frame1[i,j]

            # right eye pupil(white)
            for i in range(233,247) : 
                for j in range(360,365) :
                    r_eye_w = r_eye_w + frame1[i,j]
                for j in range(385,390) :
                    r_eye_w = r_eye_w + frame1[i,j]

            # if the color of region are similar wth a human's pupil 
            if (l_eye[1]<7000) and (l_eye[2]<7000) and (r_eye[1]<7000) and (r_eye[2]<7000) :
                if (l_eye_w[0]>3000) and (r_eye_w[0]>3000) :
                    cnt = cnt +1

            #save the image if the captured image is human's face
            if cnt != 0 and wait_time == 0:
                if cnt % cap_cnt == cap_cnt/2 :
                    cv2.imwrite("front_o.png", frame1)
                    cv2.imwrite("side_o.png", frame2)

                    
                    tmp1 = Image.open("front_o.png")
                    w1 , h1 = tmp1.size
                    #print(w1,h1)

                    #make face image simple
                    enhancer1 = ImageEnhance.Color(tmp1)
                    gray1 = enhancer1.enhance(0) # make the face image gray
                    enhancer1 = ImageEnhance.Contrast(gray1) # make the face image has more contrast 
                    cont1 = enhancer1.enhance(4)
                    crop1 = cont1.crop(( int((w1-h1)/2) , 0 , int((w1+h1)/2) , h1 ))
                    resize1 = crop1.resize((160 , 160)) #make the image crop and resize
                    resize1.save("front.jpg")

                    
                    # same process with the front face image
                    tmp2 = Image.open("side_o.png")
                    w2 , h2 = tmp2.size
                    enhancer2 = ImageEnhance.Color(tmp2)
                    gray2 = enhancer2.enhance(0)
                    enhancer2 = ImageEnhance.Contrast(gray2)
                    cont2 = enhancer2.enhance(4)
                    crop2 = cont2.crop(( int((w2-h2)/2) , 0 , int((w2+h2)/2) , h2 ))
                    resize2 = crop2.resize((160 , 160))
                    resize2.save("side.jpg")

                    msg = "Face has been captured..." # show the message on screen
                    msg_time = 10

                    
                    border_maker()  # border_maker() makes the face images more easy to distinguish
                    download_faces() # download_faces() downloads the residents' face images temporarily.
                    ret = comparison() # comparision() compare the current face with the residents' face images and return the highest similiarity resident

                    jpg_files = []
                    op_code = ''
                    
                    try :
                        f = open("faces/list.txt", 'r') # residents' face images directory
                    except :
                        continue

                    confirmed = 0
                    while True:
                        line = f.readline()
                        if not line:
                            break
                        tmp_list = line.split(',')
                        jpg_files.append(tmp_list[0]+'_front.jpg')
                        jpg_files.append(tmp_list[0]+'_side.jpg') 
                        if tmp_list[0] == str(ret) : # when the current face is a resisdent
                            msg = tmp_list[2][:-1] + 'th floor resident confirmed' # on screen message
                            msg_time = 20
                            op_code = op_code + tmp_list[2][:-1]
                            confirmed = 1
                    f.close()
                    
                    if confirmed == 0 : # when the current face is not a resisdent
                        msg = 'Cannot find your face' # on screen message
                        msg_time = 20
                        op_code = op_code + '0'

                    f_op = open("op.txt", 'w') # this file send the order to the automatic door and elevator
                    f_op.write(op_code)
                    f_op.close()

                    # remove files used for recognition
                    for idx in range(0,len(jpg_files)):
                        os.remove("./faces/"+jpg_files[idx])
                    os.remove("./faces/list.txt")
                        
                    wait_time = 200
                    
                if wait_time == 0 and (cnt != cnt_p) :
                    msg = "Eyes captured. Stay with that position"
                    msg_time = 1
                    cnt_p = cnt
                    
                if cnt % cap_cnt == 0 :
                    cnt = 0

        sleep(0.05) #framerate
        if wait_time != 0 :
            wait_time = wait_time -1
        
    cap1.release()
    cap2.release()
    cv2.destroyAllWindows()



