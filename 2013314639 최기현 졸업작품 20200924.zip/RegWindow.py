# 2013314639 Choi Gi Hyeon 최기현

import sys
from PyQt5.QtWidgets import *

class RegWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        self.setWindowTitle('Reg Window')
        self.setGeometry(100, 100, 220, 200)
        layout = QVBoxLayout()
        layout.addStretch(1)

        # floor selection
        self.lb1 = QLabel('Your floor :', self)
        self.lb1.move(20,15)

        # name box
        label1 = QLabel("Name")
        edit1 = QLineEdit()
        font1 = edit1.font()
        font1.setPointSize(20)
        edit1.setFont(font1)
        self.edit1 = edit1

        # password box
        label2 = QLabel("APT Password")
        edit2 = QLineEdit()
        font2 = edit1.font()
        font2.setPointSize(20)
        edit2.setFont(font2)
        self.edit2 = edit2
        subLayout = QHBoxLayout()

        # floor selection
        combo_box = QComboBox(self)
        combo_box.addItem('Select floor')
        combo_box.addItem('1 ')
        combo_box.addItem('2 ')
        combo_box.addItem('3 ')
        combo_box.addItem('4 ')
        combo_box.addItem('5 ')
        combo_box.move(100,15)
        combo_box.activated[str].connect(self.onActived)
        
        btnOK = QPushButton("OK")
        btnOK.clicked.connect(self.onOKButtonClicked)
        btnCancel = QPushButton("Cancel")
        btnCancel.clicked.connect(self.onCancelButtonClicked)

        layout.addWidget(label1)
        layout.addWidget(edit1)
        layout.addWidget(label2)
        layout.addWidget(edit2)
        
        subLayout.addWidget(btnOK)
        subLayout.addWidget(btnCancel)
        layout.addLayout(subLayout)

        self.setLayout(layout)
        
    def onOKButtonClicked(self):
        self.accept()
        
    def onCancelButtonClicked(self):
        self.reject()
        
    def showModal(self):
        return super().exec_()
    
    def onActived(self, text):
        self.lb1.setText(text)
        pass
