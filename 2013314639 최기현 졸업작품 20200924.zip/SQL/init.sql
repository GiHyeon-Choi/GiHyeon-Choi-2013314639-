USE facedb;
INSERT INTO `accounts` VALUES ( 1 , 'init' , 0 , '' , '');