import cv2
import time
import sys
import os

def apt_start():
    door_img = []
    for i in range(0,20) :
        filename = "door_img/" + str(i+1) + ".jpg"
        tmp = cv2.imread(filename)
        door_img.append(tmp)
    
    door_img_no = 0
    door_status = 0 #0 closed, 1 opening, 2 opened , 3 closing
    door_open_time = 0

    floor_img = []
    for i in range(0,29) :
        filename = "floor_img/" + str(i) + ".jpg"
        tmp = cv2.imread(filename)
        floor_img.append(tmp)

    # 0 ~ 28
    current_loc = 14
    target_loc = []
    resident_loc = -7

    tick = 0
    while(True):
        file = 'op.txt'
        if os.path.isfile(file):
            #자동문 부분
            
            if door_open_time == 0 : #얼굴인식직후
                
                f = open("op.txt", 'r')
                resident_loc = (int(f.readline()) *7) -7
                if resident_loc  >= 0 : #거주민이 맞으면
                    door_open_time = 70
                    door_status = 1
                if resident_loc >= 7 :#거주민이 맞고 2~5층 거주중이면
                    target_loc.append(0)
                    target_loc.append(resident_loc)
                f.close()
                
            elif door_open_time == 1 :
                door_open_time = 0
                os.remove(file)
                door_status = 3
            else :
                door_open_time = door_open_time -1


                    
        time.sleep(0.05)

        #자동문
        if door_status == 0 :
            door_img_no = 0
        elif door_status == 1 :
            if door_img_no == 19 :
                door_img_no = 0
            door_img_no = door_img_no + 1
            if door_img_no == 19:
                door_status = 2
        elif door_status == 2 :
            door_img_no = 19
        else :
            if door_img_no == 0 :
                door_img_no = 19
            door_img_no = door_img_no - 1
            if door_img_no == 1:
                door_status = 0

        if tick % 4 == 0 :
            if len(target_loc) > 0 :
                if target_loc[0] > current_loc :
                    current_loc = current_loc +1
                elif target_loc[0] < current_loc :
                    current_loc = current_loc -1
                else :
                    del target_loc[0]
            tick = 4


        merged = cv2.vconcat([door_img[door_img_no],floor_img[current_loc]])
        cv2.imshow('APT', merged)

                
        tmp_kb = cv2.waitKey(1)

        tick = tick +1

