import sys
import pymysql
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PwWindow import PwWindow
from RegWindow import RegWindow

pw = "1234"

#문과 엘리베이터의 작동 기록을 저장한 txt 로그파일 만들어보기

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setWindowTitle('Main Window')
        self.setGeometry(100, 100, 600, 600)
        layout = QVBoxLayout()
        #layout.addStretch(1)
        label = QLabel("미지정")
        label.setAlignment(Qt.AlignCenter)
        font = label.font()
        font.setPointSize(30)
        label.setFont(font)
        self.label = label
        btn1 = QPushButton("비밀번호 직접 입력")
        btn1.clicked.connect(self.onButtonClicked1)
        btn2 = QPushButton("얼굴 등록")
        btn2.clicked.connect(self.onButtonClicked2)
        layout.addWidget(label)
        layout.addWidget(btn1)
        layout.addWidget(btn2)
        #layout.addStretch(1)
        centralWidget = QWidget()
        centralWidget.setLayout(layout)
        self.setCentralWidget(centralWidget)

                
    def onButtonClicked1(self):
        global pw
        win = PwWindow()
        r = win.showModal()
        if r:
            text_pw = win.edit.text() #win(서브윈도우)의 edit을 받아옴
            if text_pw != pw :
                text = "비밀번호가 틀렸습니다."
            else :
                text = "문이 열렸습니다."
                f = open("open.txt", 'w')
                f.close()                
            self.label.setText(text)
            
    def onButtonClicked2(self):
        global pw
        win = RegWindow()
        r = win.showModal()
        if r:
            text_floor = win.lb1.text()
            text_name = win.edit1.text() #이름
            text_pw = win.edit2.text() #입력된 비밀번호
            if text_floor == '거주 층수 :' :
                text = "등록실패!\n층수를 선택 안하셨습니다."
            elif text_pw != pw :
                text = "등록실패!\n비밀번호가 틀렸습니다."
            else :
                # connect
                conn = pymysql.connect(host='localhost', user='root', password='root', db='facedb', charset='utf8')
                curs = conn.cursor()
                # SQL excute
                sql = "select * from accounts"
                curs.execute(sql)
                # data fetch
                rows = curs.fetchall()

                max_itemid = 0
                for idx in range(0,len(rows)) :
                    if rows[idx][0] > max_itemid :
                        max_itemid = rows[idx][0]

                itemid_next = str(max_itemid+1)

                img1 = open('front_border.jpg', 'rb').read()
                img2 = open('side_border.jpg', 'rb').read()

                sql_insert = "INSERT INTO accounts VALUES ( " + itemid_next + " , '"+text_name+"' , "+text_floor[:-1]+" , (%s) , (%s));"
                curs.execute(sql_insert, (img1 , img2))
                conn.close()

                text = text_name + "님 환영합니다.\n" + text_floor + " 으로 등록 되었습니다"
            self.label.setText(text)
    
    def show(self):
        super().show()
